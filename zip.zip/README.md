
# <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/YouTube_full-color_icon_%282017%29.svg/1024px-YouTube_full-color_icon_%282017%29.svg.png" alt="YouTube" height="28" alt="uTube adSkipper" />  uTube adSkipper

A very simple YouTube adSkipper

**Note :** This is an `ad skipper` not an `ad blocker` and here is how it works :

    1- Detects an ad on youtube
    2- Fast-forward the ad to the end 
    3- Trigger skip button

so you will see the first frames of the ad for a fraction of a second
<br />
Since it is an `ad skipper` not an `ad blocker`, youtube can't detect it

## How to install
### Microsoft edge
Go to [Edge Extensions](https://microsoftedge.microsoft.com/addons/detail/afglhpnmgcfoijollmiaflceepmeekop) then click `get` button

### Firefox
Go to [Firefox addons](https://addons.mozilla.org/en-US/firefox/addon/utube-adskipper/?utm_source=addons.mozilla.org&utm_medium=referral&utm_content=search)
    then add extension
